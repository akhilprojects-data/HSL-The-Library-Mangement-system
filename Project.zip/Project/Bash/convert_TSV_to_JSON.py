# Importing the necessary packages
import pandas as pd
import json
import sys

#Reading the TSV into a Dataframe
fname = raw_input()
try:
    tsv_dataframe = pd.read_csv(fname,delimiter='\t',encoding='utf-8')
except IOError:
    print("\nError opening file!")
    sys.exit()


#Conversion of Dataframe to JSON Object
dataframe_json  = tsv_dataframe.to_json(orient='table',index = False)
converted_json = json.loads(dataframe_json)

#Writing the json to a file
with open('author.json', 'w') as f:
	f.write(json.dumps(converted_json["data"]))
