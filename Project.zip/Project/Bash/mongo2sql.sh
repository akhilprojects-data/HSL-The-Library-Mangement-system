printf "\nMongoDB Name: "
read mongodbname
printf "\nMongo Username: "
read mongouser
printf "\nMongo Password: "
read -s mongopass
printf "\nMYSQL User: "
read mysqluser
printf "\nMySQL Password: "
read -s mysqlpass
printf "\nMySQL Dataabase: "
read mysqldbname
export MYSQL_PWD=$mysqlpass

printf "\nQuestion 5:"
export MYSQL_PWD=$mongopass
mongoexport --db $mongodbname -u $mongouser -p $mongopass --collection=author --type=csv --out author.csv --fields author_id,fname,lname,email

mysql -u $mysqluser -D $mysqldbname -e "LOAD DATA LOCAL INFILE 'author.csv' INTO TABLE $mysqldbname.AUTHOR FIELDS TERMINATED BY ',' IGNORE 1 LINES;"

mongoexport --db $mongodbname  -u $mongouser -p $mongopass --collection=magazine --type=csv --out magazine.csv --fields _id,magazine_name

mysql -u $mysqluser -D $mysqldbname -e "LOAD DATA LOCAL INFILE 'magazine.csv' INTO TABLE $mysqldbname.MAGAZINE FIELDS TERMINATED BY ',' IGNORE 1 LINES;"

mongoexport --db $mongodbname -u $mongouser -p $mongopass --collection=article --type=csv --out articles.csv --fields _id,title,vol_no,magazine_id,first_page,last_page

mongoexport --db $mongodbname -u $mongouser -p $mongopass --collection=volume --type=csv --out volume.csv --fields vol_no,magazine_id,year

mysql -u $mysqluser -D $mysqldbname -e "LOAD DATA LOCAL INFILE 'volume.csv' INTO TABLE $mysqldbname.VOLUME FIELDS TERMINATED BY ',' IGNORE 1 LINES;"


python articles_importer.py $mysqluser $mysqlpass $mysqldbname

rm author.csv
rm magazine.csv
rm articles.csv
rm volume.csv
printf "\nSuccess"
