import pymysql
import csv
import sys
username = sys.argv[1]
password = sys.argv[2]
dbname = sys.argv[3]
conn=pymysql.connect("localhost", username,password,dbname)
cursor=conn.cursor()       

#print "done"
csv_data = csv.reader(file('articles.csv'))
headers = next(csv_data)
headers = next(csv_data)
for row in csv_data:
	a = row[1].replace('"','')
	query = """INSERT INTO ARTICLE (article_id,title,vol_no,magazine_id,start_page,end_page) VALUES ({0}, "{1}", {2}, {3}, {4}, {5})""".format(row[0],a,row[2], row[3], row[4], row[5])
	#print(query)
	cursor.execute(query)
	conn.commit()
	#print "Done"
print "Done"
