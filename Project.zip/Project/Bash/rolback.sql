drop table if exists ITEM_TRANSACTION;
drop table if exists TRANSACTION;
drop table if exists CUSTOMER;
drop table if exists AUTHOR_ARTICLE;
drop table if exists AUTHOR;
drop table if exists ARTICLE;
drop table if exists VOLUME;
drop table if exists MAGAZINE;
drop table if exists BOOK;
drop table if exists ITEM;
drop table if exists ITEM_TYPE;

