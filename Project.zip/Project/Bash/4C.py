from pymongo import MongoClient
import json
from pprint import pprint
import sys

username = sys.argv[1]
password = sys.argv[2]
dbname = sys.argv[3]
number = sys.argv[4]
uri = "mongodb://" + username + ":" + password + "@localhost/" + dbname
#uri = "mongodb://v_boopathy:A00425792@localhost/v_boopathy"
client = MongoClient(uri)
db = client[dbname]

author = db.author
author_article = db.author_article
magazine = db.magazine
volume = db.volume
article = db.article
item = db.item

with open("articles.json") as infile:
	i = 0;
	for line in infile:
		if i>number:
			break;
		i+=1;
		data = json.loads(line)
		if data["journal"]["ftext"] in  db.magazine.find().distinct("magazine_name"):
			dummy = ""
        	else:
			new_item_id = item.insert({"_id": db.item.find().count()+4 ,"Price": "0" ,"item_id":"Magazine"})
                	magazine.insert({"_id":new_item_id,"magazine_name" : data['journal']["ftext"]})
		correct_magazine_id = db.magazine.find_one({"magazine_name":data['journal']["ftext"]},{"_id":1})
		volumes_of_magazine = db.volume.find({"magazine_id":correct_magazine_id["_id"] })
		volume_list = []
		for document in volumes_of_magazine:
			volume_list.append(document["vol_no"])
		if data['volume']["ftext"] in volume_list:
			dummy = ""
		else:
			volume.insert({"magazine_id":correct_magazine_id['_id'],"vol_no":data["volume"]["ftext"],"year":data["year"]["ftext"]})
		pages = (data["pages"]["ftext"]).split('-')
		if (len(pages)==2):
			article_id = article.insert({"magazine_id":correct_magazine_id['_id'],"vol_no":data["volume"]["ftext"],"_id":db.article.find().count()+1,"title":data["title"]["ftext"],"first_page":pages[0],"last_page":pages[1]})
		else:
			article_id = article.insert({"magazine_id":correct_magazine_id['_id'],"vol_no":data["volume"]["ftext"],"_id":db.article.find().count()+1,"title":data["title"]["ftext"],"first_page":pages[0],"last_page":pages[0]})
		author1 =[]
		if type(data["author"]) == list:
			for i in range(len(data["author"])):
				myquery = { "name":data["author"][i]["ftext"] }
				abv = len(db.author.find().distinct("_id"))+3
				author_parts = data["author"][i]["ftext"].rsplit(' ', 1)
				author_is_there = db.author.find_one({"fname":author_parts[0],"lname":author_parts[1]},{"author_id":1})
				if not author_is_there:
					author.insert({"fname":author_parts[0],"lname":author_parts[1],"_id":abv,"email":author_parts[0]+"@gmail.com"})
				correct_author_id = db.author.find_one({"fname":author_parts[0],"lname":author_parts[1]},{"_id":1})
				author_article_id = author_article.insert({"author_id":correct_author_id["_id"],"article_id":article_id})
		if type(data["author"]) == dict:
				myquery = { "name":data["author"]["ftext"] }
				agv = len(db.author.find().distinct("_id"))+3
				author_parts = data["author"]["ftext"].rsplit(' ', 1)
                                author_is_there = db.author.find_one({"fname":author_parts[0],"lname":author_parts[1]},{"author_id":1})
				if not author_is_there:
					author.insert({"fname":author_parts[0],"lname":author_parts[1],"_id":agv,"email":author_parts[0]+"@gmail.com"})
				correct_author_id = db.author.find_one({"fname":author_parts[0],"lname":author_parts[1]},{"_id":1})
				author_article_id = author_article.insert({"author_id":correct_author_id["_id"],"article_id":article_id})
		
