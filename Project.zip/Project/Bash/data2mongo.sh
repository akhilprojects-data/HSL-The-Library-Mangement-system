#!/bin/bash
pip install pymysql
pip install pymongo
pip install pandas

echo "Getting the MYSQL credentials"
printf "MYSQL Username:"
read  mysqluser
printf "MYSQL Database:"
read mysqldb
printf "MYSQL Password:"
read -s mysqlpass
printf "\n"	

printf "\nQuestion 3:"
export MYSQL_PWD=$mysqlpass 
mysql -u $mysqluser -D $mysqldb < rolback.sql
mysql -u $mysqluser -D $mysqldb < existing_tables.sql
printf "\nSuccess"

printf "\nQuestion 4A:"
mysql -u $mysqluser -D $mysqldb < new_tables.sql
printf "\nSuccess"

printf "\nQuestion 4B:"
#Piping the contents of the author table to author.tsv
mysql -u $mysqluser -D $mysqldb -e "select * from AUTHOR" > author.tsv
printf "\nSuccess"
#TSV to JSON conversion using python script
echo "author.tsv" | python convert_TSV_to_JSON.py
#Importing the JSON to Mongo
printf "\nMongo Username:"
read  mongouser
printf "\nMongo Database:"
read mongodbname
printf "\nMongo Password:"
read -s mongopass

#Deleting the existing collection in mongodb
mongo $mongodbname -u $mongouser -p $mongopass --authenticationDatabase $mongodbname < drop_collections.js
mongoimport -d $mongodbname -u $mongouser -p $mongopass -c "author" --file "author.json" --jsonArray

printf "\nQuestion 4C:"

#inserting the articles.json into the mongo collections
printf "\n No of lines to read from articles JSON:"
read nom
python 4C.py $mongouser $mongopass $mongodbname $nom
rm author.tsv
rm author.json
printf "\nSuccess"
