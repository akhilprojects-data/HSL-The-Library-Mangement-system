DROP TABLE if exists VOLUME;
 
CREATE TABLE `VOLUME` (
  `vol_no` INT NOT NULL,
  `magazine_id` INT NOT NULL,
  `year` INT NULL,
  constraint FK_MagazineVolume_MagazineId foreign key (magazine_id) references MAGAZINE(_id),
  PRIMARY KEY (`vol_no`, `magazine_id`));

DROP TABLE if exists ARTICLE;
  
CREATE TABLE `ARTICLE` (
  `article_id` INT NOT NULL auto_increment,
  `title` VARCHAR(500) NULL,
  `vol_no` INT NULL,
  `magazine_id` INT NULL,
  `start_page` INT NULL,
  `end_page` INT NULL,
  constraint FK_VolumeArticle_VolNo foreign key (vol_no) references VOLUME(vol_no),
  constraint FK_MagazineArticle_MagazineId foreign key (magazine_id) references MAGAZINE(_id),
  PRIMARY KEY (`article_id`));
  
  
DROP TABLE if exists AUTHOR_ARTICLE;

CREATE TABLE `AUTHOR_ARTICLE` (
  `author_id` INT NOT NULL,
  `article_id` INT NOT NULL,
  constraint FK_Author_AuthorArticle_AuthorId foreign key (author_id) references AUTHOR(_id),
  constraint FK_Article_AuthorArticle_ArticleId foreign key (article_id) references ARTICLE(article_id),
  PRIMARY KEY (`author_id`, `article_id`));


ALTER TABLE ITEM
ADD item_type_id INT NOT NULL DEFAULT 1;

ALTER TABLE ITEM
MODIFY _id INT not null auto_increment;

DROP TABLE if exists BOOK;

CREATE TABLE `BOOK` (
  `_id` INT NOT NULL auto_increment,
  `name` VARCHAR(100) NULL, 
  constraint FK_ItemType_Book_ItemId foreign key (_id) references ITEM(_id),
  PRIMARY KEY (`_id`));
  
DROP TABLE if exists ITEM_TYPE;

create table if not exists ITEM_TYPE (
  _id INT not null auto_increment,
  item VARCHAR(100) not null,
  primary key(_id)
) engine = innodb;

INSERT INTO ITEM_TYPE (_id, item) VALUES 
(1, "MAGAZINE"), 
(2, "BOOK");

ALTER TABLE ITEM 
ADD CONSTRAINT FK_ItemType_Item_ItemId 
foreign key (item_type_id) references ITEM_TYPE(_id);


ALTER TABLE MAGAZINE
ADD CONSTRAINT FK_ItemType_Magazine_ItemId foreign key (_id) references ITEM(_id);


DROP TABLE if exists CUSTOMER;
  
CREATE TABLE `CUSTOMER` (
  `cid` INT NOT NULL auto_increment,
  `fname` VARCHAR(100) NULL,
  `lname` VARCHAR(100) NULL,
  `tel_no` BIGINT NULL,
  `building_no` VARCHAR(45) NULL,
  `street` VARCHAR(100) NULL,
  `city` VARCHAR(45) NULL,
  `pin` VARCHAR(10) NULL,
  PRIMARY KEY (`cid`));

DROP TABLE if exists TRANSACTION;

CREATE TABLE `TRANSACTION` (
  `transaction_id` INT NOT NULL auto_increment,
  `date` DATE NOT NULL,
  `cid` INT NULL,
  `discount_code` INT NULL default 0,
  `total_price` FLOAT(8,2) NULL default 0,
  PRIMARY KEY (`transaction_id`));

DROP TABLE if exists ITEM_TRANSACTION;
  
CREATE TABLE `ITEM_TRANSACTION` (
  `item_id` INT NOT NULL,
  `transaction_id` INT NOT NULL,
  `quantity` INT not NULL default 0,
  `quantity_price` FLOAT(8,2) NULL default 0,
  constraint FK_ItemTransaction_ItemId foreign key (item_id) references ITEM(_id),
  constraint FK_ItemTransaction_TransactionId foreign key (transaction_id) references TRANSACTION(transaction_id),
  PRIMARY KEY (`item_id`, `transaction_id`));

DROP VIEW If exists CUSTOMER_DISCOUNT_CODE_VW;

CREATE VIEW `CUSTOMER_DISCOUNT_CODE_VW` AS
    SELECT 
        `t`.`cid` AS `cid`,
        (CASE
            WHEN
                ((SUM((`it`.`quantity` * `i`.`price`)) > 500))
            THEN
                5
            WHEN
                ((SUM((`it`.`quantity` * `i`.`price`)) <= 500)
                    AND (SUM((`it`.`quantity` * `i`.`price`)) > 400))
            THEN
                4
            WHEN
                ((SUM((`it`.`quantity` * `i`.`price`)) <= 400)
                    AND (SUM((`it`.`quantity` * `i`.`price`)) > 300))
            THEN
                3
            WHEN
                ((SUM((`it`.`quantity` * `i`.`price`)) <= 300)
                    AND (SUM((`it`.`quantity` * `i`.`price`)) > 200))
            THEN
                2
            WHEN
                ((SUM((`it`.`quantity` * `i`.`price`)) <= 200)
                    AND (SUM((`it`.`quantity` * `i`.`price`)) > 100))
            THEN
                1
            ELSE 0
        END) AS `code`
    FROM
        ((`ITEM_TRANSACTION` `it`
        JOIN `TRANSACTION` `t` ON ((`t`.`transaction_id` = `it`.`transaction_id`)))
        JOIN `ITEM` `i` ON ((`i`.`_id` = `it`.`item_id`)))
    WHERE (YEAR(`t`.`date`) > (YEAR(NOW()) - 5))
    GROUP BY `t`.`cid`;


-- ALTER TABLE MAGAZINE DROP INDEX INDEX_MAGAZINE;
-- CREATE INDEX INDEX_MAGAZINE ON MAGAZINE (_id, name);

-- ALTER TABLE AUTHOR DROP INDEX INDEX_AUTHOR;
-- CREATE INDEX INDEX_AUTHOR ON AUTHOR (_id, fname, lname);

-- ALTER TABLE ITEM DROP INDEX INDEX_ITEM;
-- CREATE INDEX INDEX_ITEM ON ITEM (_id, price);

-- ALTER TABLE TRANSACTION DROP INDEX INDEX_TRANSACTION;
-- CREATE INDEX INDEX_TRANSACTION ON TRANSACTION (transaction_id);