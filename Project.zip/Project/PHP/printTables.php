<html>
<head>
<title>
Print Tables.php
</title>
</head>
<body>
<center>
<?php

$table = $_POST["table"];

function prtable($table) {
	print "<table border=1>\n";
	while ($row = mysqli_fetch_row($table)) {
		print "<tr>";
		foreach ($row as $field) print "<td>$field</td>";
		print "</tr>";
	}
	print "</table>";
}

function printTable($col_result, $table) {
	print "<table border=1>\n";
	printColumn($col_result);
	while ($row = mysqli_fetch_row($table)) {
		print "<tr>";
		foreach ($row as $field) print "<td>$field</td>";
		print "</tr>";
	}
	print "</table>";
}

function printColumn($column) {
	print "<tr>";
	while ($row = mysqli_fetch_row($column)) {
		print "<td>$row[0]</td>";
	}
	print "</tr>";
}

require("/home/student_2018_fall/s_punnoli/db.php");

$link = mysqli_connect($host, $user, $pass);
if (!$link) die("Couldn't connect to MySQL");

mysqli_select_db($link, $db)
	or die("Couldn't open $db: ".mysqli_error($link));

$col_result = mysqli_query($link, "select column_name from INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME='$table'");
$result = mysqli_query($link, "select * from $table");

if (!$result) print("ERROR: ".mysqli_error($link));
else {
    $num_rows = mysqli_num_rows($result);
    print "There are $num_rows rows in the table<p>";
    printTable($col_result, $result);
}

mysqli_close($link);
?>

<p>
<a href="showTables.php"> Go Back to Show Tables </a><br>
<a href="main.php"> back to MAIN menu</a>
</center>
</body>
</html>