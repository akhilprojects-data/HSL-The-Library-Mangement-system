<html>
<head>
<title>
Add Transaction
</title>
</head>
<body>

<?php
require("/home/student_2018_fall/s_punnoli/db.php");

$link = mysqli_connect($host, $user, $pass, $db);
if (!$link) die("Couldn't connect to MySQL");

$cus_dis = array();
$cdc_view = mysqli_query($link, "select cid,code from CUSTOMER_DISCOUNT_CODE_VW");
while ($row = mysqli_fetch_row($cdc_view)) {
	$cus_dis[$row[0]] = $row[1];
}

$mag_price = array();
$mag = mysqli_query($link, "select m._id, i.price from MAGAZINE m inner join ITEM i on i._id=m._id");
while ($row = mysqli_fetch_row($mag)) {
	$mag_price[$row[0]] = $row[1];
}

function getTransactionId($link)
{
	$tid = mysqli_query($link, "select max(transaction_id) from TRANSACTION");
	$t_id = 0;
	while ($row = mysqli_fetch_row($tid)) {
		$t_id = $row[0];
	}
	return $t_id;
}

if( isset($_POST['submit']) ){
 	$c_id = htmlentities($_POST['c_id']);
    $i_ids = htmlentities($_POST['i_ids']);
    $quants = htmlentities($_POST['quants']);

    $item_ids = explode(',', $i_ids);
    $item_quants = explode(',', $quants);

    if (sizeof($item_ids)==sizeof($item_quants)){
    	$t_id = getTransactionId($link) + 1;

		$total_price = 0;
    	for ($i=0; $i < sizeof($item_ids); $i++) { 
    		$total_price = $total_price + ($mag_price[$item_ids[$i]] * $quants[$i]);
    	}

    	$dc = $cus_dis[$c_id];
	if (!$dc){
	$dc = 0;
	}
    	$tp = $total_price * (1-2.5*$dc/100);
    	mysqli_query($link,"insert INTO TRANSACTION VALUES ($t_id, NOW(), $c_id, $dc, $tp)");

		$t_id = getTransactionId($link);
		for ($i=0; $i < sizeof($item_ids); $i++) {
			$item = $item_ids[$i];
			$qp = $mag_price[$item] * $item_quants[$i];

			mysqli_query($link,"insert into ITEM_TRANSACTION VALUES ($item, $t_id, $item_quants[$i], $qp)");
		}
	print "Transaction added successfully<p>";
	print "Total Transaction Value is $ $tp and customer has got a discount of $dc";
    } else {
    	 die("size of quantity and item are different");
    }
    
}
?>
<center>
<h1>Add Transaction Page</h1>
<br><br><br>
<h3> please add transaction by filling up the below form </h3>
<form name ="transactionAdd" action="" method="post">
<table name="data">
<tr>
<th>Customer Id :</th><th><input name="c_id" type="text"></th>
</tr>
<tr>
<th>Item Ids :</th><th><input name="i_ids" type="text"></th>
</tr>
<tr>
<th>Quantities :</th><th><input name="quants" type="text"></th>
</tr>
</table>
<input type="submit" value="submit" name="submit"> <input type="reset" value="reset" name="reset">
</form>
<a href="main.php">click to go to main page</a>
</body>
</html>
