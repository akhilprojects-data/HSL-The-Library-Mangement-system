<html>
<head><title>Add Article</title></head>
<body>
<?php
require("/home/student_2018_fall/s_punnoli/db.php");
if( isset($_POST['submit']) ){
    $title = htmlentities($_POST['title']);
    $pgst = htmlentities($_POST['pgst']);
    $pgend = htmlentities($_POST['pgend']);
    $magazine = htmlentities($_POST['magazine']);
    $author = htmlentities($_POST['author']);
	$volume = htmlentities($_POST['volume']);

    $conn = mysqli_connect($host, $user, $pass, $db);
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    if($title == NULL or $pgst == NULL or $pgend == NULL or $magazine == NULL or $author == NULL){
        echo "<script> alert(\"Please enter the below fields \")</script>";
    } else {

        $sql = "INSERT INTO ARTICLE (title, vol_no, magazine_id, start_page, end_page) VALUES (\"".$title."\",\"".$volume."\",\"".$magazine. "\",\"".$pgst."\",\"".$pgend."\")";
		print $sql;
        if (mysqli_multi_query($conn, $sql)) {
            echo "<center> New records created successfully</center>";
        } else {
	    echo "<center> Error: " . $sql . "<br>" . mysqli_error($conn) ."</center>";
        }
    }

mysqli_close($conn);
}
?>

<center>
<h1>Add Article Page</h1>
<br><br><br>
<h3> please add article by filling up the below form </h3>
<form name ="articleAdd" action="" method="post">
<table name="data"> 
<tr>
<th>Title :</th><th><input name="title" type="text" ></th>
</tr>
<tr>
<th>Volume :</th><th><input name="volume" type="text" ></th>
</tr>
<tr>
<th>Page Start :</th><th><input name="pgst" type="text" ></th>
</tr>
<tr>
<th>Page End :</th><th><input name="pgend" type="text" ></th>
</tr>
<tr>
<th>Magazine :</th><th>
<select name="magazine">
<?php

function prAuthortable($table) {
        while ($i_row = @mysqli_fetch_row($table)) {
		print "<option value=\"$i_row[0]\">$i_row[1]</option>";
        }
}
function prMagzinetable($table) {
        while ($i_row = @mysqli_fetch_row($table)) {
		print "<option value=\"$i_row[0]\">$i_row[1]</option>";
        }
}
require("/home/student_2018_fall/s_punnoli/db.php");
$link = @mysqli_connect($host, $user, $pass, $db);
if (!$link) die("Couldn't connect to MySQL");

mysqli_select_db($link, $db)
        or die("Couldn't open $db: ".mysqli_error($link));

$result = mysqli_query($link, "SELECT _id,name FROM MAGAZINE");

prMagzinetable($result);

mysqli_close($link);

?>
</select>
</th>
</tr>
<tr>
<th>Author :</th><th>
<select name="author" multiple>
<?php
require("/home/student_2018_fall/s_punnoli/db.php");
$link = mysqli_connect($host, $user, $pass, $db);
if (!$link) die("Couldn't connect to MySQL");

mysqli_select_db($link, $db)
        or die("Couldn't open $db: ".mysqli_error($link));

$result = mysqli_query($link, "SELECT lname,fname,_id FROM AUTHOR");

prAuthortable($result);

mysqli_close($link);

?>
</select>
</th>
</tr>
</table>
<input type="submit" value="submit" name="submit"> <input type="reset" value="reset" name="reset">
</form>
<a href="main.php"> Go Back to Main Menu</a>
</center>
</body>
</html>
