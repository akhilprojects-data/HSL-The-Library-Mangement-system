<html>
<head>
<title>
Show All Tables
</title>
</head>
<body>
<center>
<form action="printTables.php" method="POST">
<b>Enter the name of the table</b>
<input type="text" name="table">
<p>
<input type="submit" value="submit">
</form>
<?php

function prtable($table) {
        print "<table border=1>\n";
	print "<tr><td>Name Of The Table</td></tr>";
        while ($a_row = mysqli_fetch_row($table)) {
                print "<tr>";
                foreach ($a_row as $field) print "<td>$field</td>";
                print "</tr>";
        }
        print "</table>";
}

require("/home/student_2018_fall/s_punnoli/db.php");
$link = mysqli_connect($host, $user, $pass, $db);
if (!$link) die("Couldn't connect to MySQL");

mysqli_select_db($link, $db)
        or die("Couldn't open $db: ".mysqli_error($link));

$table = "users";
$result = mysqli_query($link, "SHOW TABLES FROM $db");
$num_rows = mysqli_num_rows($result);
print "There are $num_rows tables<p>";

prtable($result);

mysqli_close($link);

?>
<a href="main.php">Go Back to Main Menu</a>
</center>
</body>

</html>

