<html>
<head>
<title>
Add Customer.php
</title>
</head>
<body>

<?php
if(isset($_POST['submit']) || isset($_POST['Yes']) || isset($_POST['No'])){
$fname = htmlentities($_POST["fname"]);
$lname = htmlentities($_POST["lname"]);
$telephone = htmlentities($_POST["telephone"]);
$building = htmlentities($_POST["building"]);
$street = htmlentities($_POST["street"]);
$city = htmlentities($_POST["city"]);
$pincode = htmlentities($_POST["pincode"]);


require("/home/student_2018_fall/s_punnoli/db.php");

$link = mysqli_connect($host, $user, $pass);
if (!$link) die("Couldn't connect to MySQL");

mysqli_select_db($link, $db)
	or die("Couldn't open $db: ".mysqli_error($link));

$rows = mysqli_query($link, "SELECT * FROM CUSTOMER where fname = '$fname' and lname = '$lname'");
if (!$rows) print("ERROR: ".mysqli_error($link));
if($_POST['submit']){
if (mysqli_num_rows($rows) != 0)
	{
				echo "<form action=\"\" method=\"POST\">A customer with same First Name and Last Name exsist! Do you want to add again?
				<br> <input type=\"submit\" name=\"Yes\" value=\"Yes\"> <input type=\"submit\" name=\"No\" value=\"No\"> 
				<input type=\"hidden\" name=\"fname\" value=\"".$fname."\">
				<input type=\"hidden\" name=\"lname\" value=\"".$lname."\">
	        	<input type=\"hidden\" name=\"telephone\" value=\"".$telephone."\">
	            <input type=\"hidden\" name=\"building\" value=\"".$building."\">
				<input type=\"hidden\" name=\"street\" value=\"".$street."\">
				<input type=\"hidden\" name=\"city\" value=\"".$city."\">
				<input type=\"hidden\" name=\"pincode\" value=\"".$pincode."\">
				</form>";
				exit;
				
	}else{
		$result = mysqli_query($link, "INSERT into CUSTOMER (fname,lname,tel_no,building_no,street,city,pin)
		values ('$fname','$lname','$telephone','$building','$street','$city','$pincode')");

		if (!$result){ 
			print("ERROR: ".mysqli_error($link));
		}else {
    		print "<b>NEW CUSTOMER SCUESSFULLY ADDED</b>";
		}
	}
}elseif($_POST['Yes']){

	$result = mysqli_query($link, "INSERT into CUSTOMER (fname,lname,tel_no,building_no,street,city,pin)
		values ('$fname','$lname','$telephone','$building','$street','$city','$pincode')");

	if (!$result) print("ERROR: ".mysqli_error($link));
		else {
    		print "<b>NEW CUSTOMER SCUESSFULLY ADDED</b>";
			  }
}else{
	print "<b>NEW CUSTOMER NOT SCUESSFULLY ADDED</b>";
			  }

mysqli_close($link);
}
?>


<center>
<form action="" method="POST">

<b>Enter Customer details:</b>
<table name="data"> 
<tr>
<th>First Name</th><th><input type="text" name="fname"></th>
</tr>
<tr>
<th>Last Name</th><th><input type="text" name="lname"></th>
</tr>
<tr>
<th>Telephone Number</th><th><input type="text" name="telephone"></th>
</tr>
<tr>
<th>Building Number</th><th><input type="text" name="building"></th>
</tr>
<tr>
<th>Street</th><th><input type="text" name="street"></th>
</tr>
<tr>
<th>City</th><th><input type="text" name="city"></th>
</tr>
<tr>
<th>Pin Code</th><th><input type="text" name="pincode"></th>
</tr>
</table>
<input name="submit" type="submit" value="Add Customer">
 
</form>

<p>

<a href="main.php">Go Back to Main Menu</a>

</body>
</html>