<html>
<head>
<title>
Delete Transaction 
</title>
</head>
<body>

<?php
if(isset($_POST['submit'])){
$trnxId = htmlentities($_POST["trnxId"]);

require("/home/student_2018_fall/s_punnoli/db.php");

$link = mysqli_connect($host, $user, $pass);
if (!$link) die("Couldn't connect to MySQL");

mysqli_select_db($link, $db)
	or die("Couldn't open $db: ".mysqli_error($link));

$result = mysqli_query($link, "delete from ITEM_TRANSACTION where transaction_id=$trnxId");

if (!$result) print("ERROR: ".mysqli_error($link));
	else {
		print "<b>Item Transaction Deleted<br></b>";
		  }

$result = mysqli_query($link, "delete from TRANSACTION where transaction_id=$trnxId");

if (!$result) print("ERROR: ".mysqli_error($link));
	else {
		print "<b>Transaction Deleted</b></br>";
		  }


mysqli_close($link);

}
?>

<center>
<form action="" method="POST">
<b>Enter Transaction details:</b>

<table>
<tr>
<th>Transaction Id</th><th><input type="text" name="trnxId"></th>
</tr>
</table>
	
<input name="submit" type="submit" value="Delete Transaction">
</form>

<p>

<a href="main.php">Go Back to Main Menu</a>

</body>
</html>