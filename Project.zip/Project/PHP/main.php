<html>
<head> <title>Main Page</title> </head> 
<body>
<center>
<h1>WELCOME</h1><br>

<a href="showTables.php">Show All DB Tables</a><br>
<a href="article.php">Add Article</a><br>
<a href="customer.php">Add Customer</a><br>
<a href="addTransaction.php">Create Transaction</a><br>
<a href="deleteTransaction.php">Delete Transaction</a><br>

<?php
?>
</center>
</body>
</html>