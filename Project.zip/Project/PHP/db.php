	<?php
        $host ="dev.cs.smu.ca:3306";
        $user = "s_punnoli";  // your user name
		$pass = "A00429404";  // your password
		$db = "s_punnoli";  // the name of your database
	?>
   
  
